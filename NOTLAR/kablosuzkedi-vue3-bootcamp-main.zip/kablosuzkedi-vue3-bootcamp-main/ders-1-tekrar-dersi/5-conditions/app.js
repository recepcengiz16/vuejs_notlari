const app = Vue.createApp({
  data() {
    return {
      showState: false,
      counter: 0,
    };
  },
}).mount("#app");
