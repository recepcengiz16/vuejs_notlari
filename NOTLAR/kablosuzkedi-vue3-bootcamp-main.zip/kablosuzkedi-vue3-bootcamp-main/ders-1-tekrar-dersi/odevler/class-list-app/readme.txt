ÖDEV
Yukarıda bulunan checkbox elementlerine tıklanıldığında, checkbox'ın sahip olduğu Class bilgisini textarea elementine verecek Vue uygulamasını yazınız.
When the above checkbox elements are clicked, write the Vue application that will give the Class information of the checkbox to the textarea element.

İPUCU
Background Color, Border, Color, Font Bold, Border Radius, Font Italic için birer CSS Class'ı oluşturarak, her bir checkbox için v-model ile kontrol yapabilirsiniz.
By creating a CSS Class for Background Color, Border, Color, Font Bold, Border Radius, Font Italic, you can control each checkbox with a v-model.