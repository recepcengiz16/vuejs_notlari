ÖDEV
1 - ) data üzerinde bulunan bir comments isimli bir Array üzerinden ".comment--item" elementini v-for ile döndürünüz.
1 - ) iterate the ".comment - item" element with v-for over an Array named comments on the data.
2 - ) Kullanıcı Beğendim / Beğenmedim butonuna tıkladığında, üzerinde yazan sayaçları arttırınız. Yani Beğendim (5) Beğenmedim (10) gibi.
2 - ) When the user clicks on the Like / Dislike button, increase the counters written on it. So I Like (5) Like I Don't Like (10).

İPUCU:
Beğeni sayılarını comments içerisinde tutabilirsiniz.
You can keep the number of likes in the comments.

NOT:
Beğeni sayılarının sürekli artmasının bir önemi yoktur.
It doesn't matter that the number of likes is constantly increasing.