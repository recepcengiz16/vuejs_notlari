const app = Vue.createApp({
  data() {
    return {};
  },
}).mount("#app");
