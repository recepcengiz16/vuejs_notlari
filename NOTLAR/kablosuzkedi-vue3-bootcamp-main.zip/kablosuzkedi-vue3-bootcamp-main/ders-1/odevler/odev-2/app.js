const app = Vue.createApp({
  data() {
    return {
      value: "",
    };
  },
});
app.mount("#exercise");
