<template>
  <slot />
</template>
<script>
export default {
  mounted() {
    console.log("GREEN mounted");
  }
};
</script>
