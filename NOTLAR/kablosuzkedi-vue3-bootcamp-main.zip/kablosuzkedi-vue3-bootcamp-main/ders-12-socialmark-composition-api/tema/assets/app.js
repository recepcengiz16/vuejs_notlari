const app = Vue.createApp({}).mount("#app");
