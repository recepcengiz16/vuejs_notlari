<template>
  <div class="container p-3">
    <h3 class="text-center">Bookmark List</h3>
    <div class="row">
      <div class="col-8 offset-2">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>
