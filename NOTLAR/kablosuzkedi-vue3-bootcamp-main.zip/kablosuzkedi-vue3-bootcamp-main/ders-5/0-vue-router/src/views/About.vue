<template>
  <h1>About</h1>
  <p>
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur dignissimos accusantium nam maxime doloremque ab consequatur culpa ipsa
    consectetur earum neque, in deserunt suscipit animi facilis, voluptatum adipisci odit hic!
  </p>
</template>
