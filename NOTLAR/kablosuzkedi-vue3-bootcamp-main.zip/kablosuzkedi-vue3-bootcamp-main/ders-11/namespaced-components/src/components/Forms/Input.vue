<template>
  <slot />
  <input type="text" />
</template>
